import { CyberLayout } from '@/components/CyberLayout';
import { SessionControl } from '@/components/SessionControl';
import { ActiveSessions } from '@/components/ActiveSessions';
import { TerminalLog } from '@/components/Terminal.tsx';
import { Activity, Server, Database, ShieldAlert } from 'lucide-react';

export default function Dashboard() {
  const colorMap: Record<string, { bg: string, text: string, border: string }> = {
    blue: { bg: 'bg-blue-500/10', text: 'text-blue-500', border: 'border-blue-500/20' },
    green: { bg: 'bg-green-500/10', text: 'text-green-500', border: 'border-green-500/20' },
    purple: { bg: 'bg-purple-500/10', text: 'text-purple-500', border: 'border-purple-500/20' },
    red: { bg: 'bg-red-500/10', text: 'text-red-500', border: 'border-red-500/20' },
  };

  const StatCard = ({ label, value, icon: Icon, color }: any) => {
    const styles = colorMap[color] || colorMap.blue;
    return (
      <div className="cyber-panel p-4 rounded-lg flex items-center justify-between group hover:border-primary/50 transition-colors">
        <div>
          <p className="text-xs text-muted-foreground font-mono uppercase mb-1">{label}</p>
          <h3 className="text-2xl font-bold font-mono text-foreground group-hover:text-primary transition-colors">{value}</h3>
        </div>
        <div className={`p-3 rounded-full ${styles.bg} ${styles.text} border ${styles.border}`}>
          <Icon size={24} />
        </div>
      </div>
    );
  };

  return (
    <CyberLayout>
      <div className="space-y-6">
        {/* Header Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Total Messages" value="1,240,592" icon={Database} color="blue" />
          <StatCard label="Active Bots" value="14" icon={Server} color="green" />
          <StatCard label="Uptime" value="99.9%" icon={Activity} color="purple" />
          <StatCard label="Failed" value="0.01%" icon={ShieldAlert} color="red" />
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
          {/* Left: Controls */}
          <div className="lg:col-span-2 space-y-6 flex flex-col">
            <div className="flex-1">
              <SessionControl />
            </div>
            <div className="h-[250px]">
              <TerminalLog />
            </div>
          </div>

          {/* Right: Active Sessions */}
          <div className="lg:col-span-1 h-full">
            <ActiveSessions />
          </div>
        </div>
      </div>
    </CyberLayout>
  );
}
