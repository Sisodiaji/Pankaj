import React, { useState, useEffect, useRef } from 'react';
import { Camera, FileText, User, Clock, Zap, Shield, Play, Pause, Upload, Settings, RefreshCw } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { io, Socket } from 'socket.io-client';

// Rain effect component
const MatrixRain = () => {
  return (
    <div className="rain-container">
      {Array.from({ length: 50 }).map((_, i) => (
        <div 
          key={i}
          className="rain-drop"
          style={{
            left: `${Math.random() * 100}%`,
            animationDuration: `${0.5 + Math.random() * 1.5}s`,
            animationDelay: `${Math.random() * 2}s`
          }}
        />
      ))}
    </div>
  );
};

export default function SonuSinghServer() {
  const { toast } = useToast();
  const [isRunning, setIsRunning] = useState(false);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [cookies, setCookies] = useState('');
  const [targetId, setTargetId] = useState('');
  const [delay, setDelay] = useState(60);
  const [messages, setMessages] = useState('');
  const [extractedUid, setExtractedUid] = useState<string | null>(null);
  const [currentSession, setCurrentSession] = useState<string | null>(null);
  const [messageCount, setMessageCount] = useState(0);
  const [lastMessage, setLastMessage] = useState('');
  const socketRef = useRef<Socket | null>(null);
  const messageFileRef = useRef<File | null>(null);

  // Socket.IO connection
  useEffect(() => {
    const socket = io();
    socketRef.current = socket;

    socket.on('connect', () => {
      console.log('Connected to server');
    });

    socket.on('session-update', (data: any) => {
      if (data.sessionId === currentSession) {
        setMessageCount(data.messageCount || 0);
        setLastMessage(data.lastMessage || '');
        
        if (data.status === 'stopped') {
          setIsRunning(false);
        }
      }
    });

    socket.on('session-deleted', (data: any) => {
      if (data.sessionId === currentSession) {
        setIsRunning(false);
        setCurrentSession(null);
        setMessageCount(0);
        setLastMessage('');
      }
    });

    return () => {
      socket.disconnect();
    };
  }, [currentSession]);

  // Auto-extract UID from cookies if pasted
  useEffect(() => {
    if (cookies.includes('c_user')) {
      try {
        const match = cookies.match(/c_user=(\d+)/);
        if (match && match[1]) {
          setExtractedUid(match[1]);
          toast({
            title: "UID Extracted",
            description: `Found User ID: ${match[1]}`,
            className: "bg-[#050b14] border-primary text-primary"
          });
        }
      } catch (e) {
        // ignore parsing errors
      }
    }
  }, [cookies]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleMessageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      messageFileRef.current = file;
      toast({
        title: "File Uploaded",
        description: `${file.name} ready to send`,
        className: "bg-[#050b14] border-primary text-primary"
      });
    }
  };

  const handleStart = async () => {
    if (isRunning && currentSession) {
      // Stop the session
      try {
        const response = await fetch(`/api/sessions/${currentSession}/stop`, {
          method: 'POST',
          headers: {
            'x-user-id': 'default-user'
          }
        });

        if (response.ok) {
          setIsRunning(false);
          toast({
            title: "Server Stopped",
            description: "Process terminated.",
            className: "bg-[#050b14] border-primary text-primary"
          });
        }
      } catch (error) {
        console.error('Stop error:', error);
        toast({
          title: "Error",
          description: "Failed to stop server",
          variant: "destructive"
        });
      }
      return;
    }

    // Start new session
    if (!cookies || !targetId || (!messages && !messageFileRef.current)) {
      toast({
        title: "Error",
        description: "Please fill all required fields",
        variant: "destructive"
      });
      return;
    }

    try {
      const formData = new FormData();
      formData.append('cookies', cookies);
      formData.append('targetId', targetId);
      formData.append('delay', delay.toString());
      
      if (messageFileRef.current) {
        formData.append('messageFile', messageFileRef.current);
      } else {
        formData.append('messages', messages);
      }

      const response = await fetch('/api/sessions/start', {
        method: 'POST',
        headers: {
          'x-user-id': 'default-user'
        },
        body: formData
      });

      const data = await response.json();

      if (response.ok) {
        setIsRunning(true);
        setCurrentSession(data.sessionId);
        toast({
          title: "Server Started",
          description: "Running 24/7 background process...",
          className: "bg-[#050b14] border-primary text-primary"
        });
      } else {
        toast({
          title: "Error",
          description: data.error || "Failed to start server",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Start error:', error);
      toast({
        title: "Error",
        description: "Failed to connect to server",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-6 pb-20 relative font-sans">
      <MatrixRain />
      <Toaster />
      <TooltipProvider>
        <div className="max-w-md mx-auto space-y-8 relative z-10">
          
          {/* Header / DP Section */}
          <div className="flex flex-col items-center justify-center mb-8 space-y-4">
            <div className="relative group">
              <div className="w-32 h-32 rounded-full border-4 border-primary shadow-[0_0_20px_rgba(0,243,255,0.5)] overflow-hidden bg-black/50 relative">
                {profileImage ? (
                  <img src={profileImage} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-primary/50">
                    <User size={48} />
                  </div>
                )}
                <label className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                  <Camera className="text-primary" />
                  <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                </label>
              </div>
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-primary text-black text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                ADMIN
              </div>
            </div>
            <h1 className="text-3xl font-display font-bold text-primary glow-text text-center uppercase tracking-widest">
              Sonu Singh
              <span className="block text-sm font-sans font-normal opacity-70 mt-1 tracking-normal">Multi-Cookie Server</span>
            </h1>
          </div>

          {/* Status Banner */}
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${isRunning ? 'bg-green-500 animate-pulse shadow-[0_0_10px_#22c55e]' : 'bg-red-500'}`} />
              <span className="text-primary font-mono text-sm">{isRunning ? 'SYSTEM ONLINE' : 'SYSTEM OFFLINE'}</span>
            </div>
            <span className="text-primary/60 text-xs font-mono">v2.0.5</span>
          </div>

          {/* Stats Display */}
          {isRunning && (
            <div className="bg-primary/10 border border-primary/30 rounded-lg p-4 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs text-primary/70 uppercase font-bold">Messages Sent</span>
                <span className="text-xl font-bold text-primary font-mono">{messageCount}</span>
              </div>
              {lastMessage && (
                <div className="pt-2 border-t border-primary/20">
                  <span className="text-[10px] text-primary/70 uppercase font-bold block mb-1">Last Message</span>
                  <p className="text-xs text-primary font-mono truncate">{lastMessage}</p>
                </div>
              )}
            </div>
          )}

          {/* SENDER NAME / COOKIES SECTION */}
          <div className="neon-box">
            <div className="neon-label">
              <FileText size={20} />
              <span>Multi-Cookie Input</span>
            </div>
            <div className="space-y-4">
              <div className="relative">
                <div className="absolute top-0 right-0 px-2 py-1 bg-primary/20 text-primary text-[10px] rounded-bl-lg rounded-tr-lg font-mono">
                  JSON / STRING
                </div>
                <textarea 
                  value={cookies}
                  onChange={(e) => setCookies(e.target.value)}
                  placeholder='Paste your cookies here (supports multiple format)...'
                  className="neon-input min-h-[120px] resize-none text-xs"
                  disabled={isRunning}
                />
              </div>
              
              {extractedUid && (
                <div className="flex items-center gap-2 px-3 py-2 bg-primary/10 rounded border border-primary/30">
                  <Shield size={14} className="text-primary" />
                  <span className="text-xs text-primary font-mono">Detected UID: {extractedUid}</span>
                </div>
              )}
              
              <div className="bg-black/40 rounded-lg p-2 border border-primary/30">
                <div className="text-[10px] text-primary/70 uppercase mb-1 font-bold ml-1">Credits</div>
                <div className="text-xs text-primary font-mono pl-1">© SONU SINGH 2025</div>
              </div>
            </div>
          </div>

          {/* GROUP / THREAD IDS SECTION */}
          <div className="neon-box">
            <div className="neon-label">
              <User size={20} />
              <span>Target Configuration</span>
            </div>
            <div className="space-y-4">
              <div className="flex flex-col gap-2">
                <label className="text-xs text-primary/70 uppercase font-bold">Target ID / Group UID</label>
                <input 
                  type="text" 
                  value={targetId}
                  onChange={(e) => setTargetId(e.target.value)}
                  placeholder="100012345678901" 
                  className="neon-input"
                  disabled={isRunning}
                />
              </div>
              
              <div className="flex flex-col gap-2">
                <label className="text-xs text-primary/70 uppercase font-bold">Message File (.txt) or Text</label>
                <div className="relative border border-dashed border-primary/50 rounded-md p-4 bg-black/20 hover:bg-primary/5 transition-colors cursor-pointer group text-center">
                  <input 
                    type="file" 
                    accept=".txt"
                    className="absolute inset-0 opacity-0 cursor-pointer" 
                    onChange={handleMessageFileUpload}
                    disabled={isRunning}
                  />
                  <Upload className="mx-auto text-primary/50 group-hover:text-primary mb-2 transition-colors" size={20} />
                  <span className="text-xs text-muted-foreground font-mono group-hover:text-primary/80">
                    {messageFileRef.current ? messageFileRef.current.name : 'UPLOAD_PAYLOAD'}
                  </span>
                </div>
              </div>

               <div className="flex flex-col gap-2">
                <label className="text-xs text-primary/70 uppercase font-bold">Or Type Messages (one per line)</label>
                <textarea 
                  value={messages}
                  onChange={(e) => setMessages(e.target.value)}
                  placeholder="Enter messages (one per line)..." 
                  className="neon-input min-h-[80px]"
                  disabled={isRunning}
                />
              </div>
            </div>
          </div>

          {/* MESSAGE DELAY SECTION */}
          <div className="neon-box">
            <div className="neon-label">
              <Clock size={20} />
              <span>Message Delay</span>
            </div>
            <div className="space-y-4">
               <div className="flex items-center gap-4">
                 <input 
                    type="range" 
                    min="1" 
                    max="3600" 
                    value={delay}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      setDelay(isNaN(val) ? 60 : Math.max(1, Math.min(3600, val)));
                    }}
                    className="w-full accent-primary h-2 bg-black/50 rounded-lg appearance-none cursor-pointer"
                    disabled={isRunning}
                  />
                  <input 
                    type="number" 
                    value={delay}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      if (!isNaN(val)) {
                        setDelay(Math.max(1, Math.min(3600, val)));
                      }
                    }}
                    onBlur={(e) => {
                      const val = parseInt(e.target.value);
                      if (isNaN(val) || val < 1) {
                        setDelay(60);
                      }
                    }}
                    className="neon-input w-24 text-center"
                    disabled={isRunning}
                  />
               </div>
               <p className="text-[10px] text-primary/50 text-center font-mono">Recommended: 60s to avoid ban</p>
            </div>
          </div>

           {/* SERVER SETTINGS */}
          <div className="neon-box">
            <div className="neon-label">
              <Settings size={20} />
              <span>Server Settings</span>
            </div>
            <div className="space-y-3">
               <div className="flex items-center justify-between p-2 rounded bg-primary/5 border border-primary/20">
                 <div className="flex items-center gap-2">
                   <RefreshCw size={16} className="text-primary" />
                   <span className="text-sm text-primary font-mono">Auto-Restart (24h)</span>
                 </div>
                 <div className="w-10 h-5 bg-primary/20 rounded-full relative cursor-pointer border border-primary">
                   <div className="absolute right-1 top-0.5 w-3.5 h-3.5 bg-primary rounded-full shadow-[0_0_10px_#00f3ff]"></div>
                 </div>
               </div>
               
               <div className="flex items-center justify-between p-2 rounded bg-primary/5 border border-primary/20">
                 <div className="flex items-center gap-2">
                   <Zap size={16} className="text-primary" />
                   <span className="text-sm text-primary font-mono">Anti-Ban Mode</span>
                 </div>
                 <div className="w-10 h-5 bg-primary/20 rounded-full relative cursor-pointer border border-primary">
                   <div className="absolute right-1 top-0.5 w-3.5 h-3.5 bg-primary rounded-full shadow-[0_0_10px_#00f3ff]"></div>
                 </div>
               </div>
            </div>
          </div>

          {/* ACTION BUTTON */}
          <button 
            onClick={handleStart}
            className={`neon-button flex items-center justify-center gap-3 text-lg ${isRunning ? 'animate-pulse bg-red-500/10 border-red-500 text-red-500 shadow-red-500/20' : ''}`}
          >
            {isRunning ? (
              <>
                <Pause size={24} /> STOP SERVER
              </>
            ) : (
              <>
                <Play size={24} /> START SERVER
              </>
            )}
          </button>

          <div className="text-center text-primary/30 text-[10px] font-mono mt-8">
            SESSION ID: {currentSession || 'N/A'}
            <br/>
            SERVER TIME: {new Date().toLocaleTimeString()}
          </div>

        </div>
      </TooltipProvider>
    </div>
  );
}
