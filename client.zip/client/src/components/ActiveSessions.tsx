import { Activity, StopCircle, RefreshCw, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const SESSIONS = [
  { id: 'sess_8f92a', target: 'Mark Z.', status: 'RUNNING', count: 1420, lastMsg: 'System update required...', time: '00:42:15' },
  { id: 'sess_2b1c9', target: 'Elon M.', status: 'STOPPED', count: 89, lastMsg: 'To the moon!', time: '00:00:00' },
  { id: 'sess_7d3e1', target: 'Cyber_Test', status: 'RUNNING', count: 42, lastMsg: 'Test sequence 42', time: '00:01:30' },
];

export function ActiveSessions() {
  return (
    <div className="cyber-panel p-6 rounded-lg h-full flex flex-col">
      <div className="flex items-center justify-between mb-6 border-b border-border/50 pb-4">
        <div className="flex items-center gap-2">
          <Activity className="text-primary" size={20} />
          <h2 className="font-mono text-lg font-bold tracking-wider">ACTIVE_THREADS</h2>
        </div>
        <Badge variant="outline" className="font-mono text-primary border-primary/30">
          {SESSIONS.filter(s => s.status === 'RUNNING').length} ACTIVE
        </Badge>
      </div>

      <div className="space-y-3 flex-1 overflow-y-auto pr-2">
        {SESSIONS.map((session) => (
          <div key={session.id} className="group bg-black/20 hover:bg-primary/5 border border-border/50 hover:border-primary/30 p-4 rounded transition-all duration-300">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${session.status === 'RUNNING' ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                <span className="font-mono text-xs text-muted-foreground uppercase">{session.id}</span>
              </div>
              <Badge 
                variant="outline" 
                className={`font-mono text-[10px] ${
                  session.status === 'RUNNING' 
                    ? 'border-green-500/30 text-green-500 bg-green-500/5' 
                    : 'border-red-500/30 text-red-500 bg-red-500/5'
                }`}
              >
                {session.status}
              </Badge>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-3">
              <div>
                <span className="text-[10px] text-muted-foreground font-mono block mb-1">TARGET</span>
                <span className="text-sm font-bold truncate block">{session.target}</span>
              </div>
              <div>
                <span className="text-[10px] text-muted-foreground font-mono block mb-1">MESSAGES</span>
                <span className="text-sm font-bold block text-primary">{session.count.toLocaleString()}</span>
              </div>
            </div>

            <div className="bg-black/40 p-2 rounded mb-3 border border-white/5">
              <div className="flex items-center gap-2 text-[10px] text-muted-foreground font-mono mb-1">
                <MessageCircle size={10} />
                LAST_PAYLOAD
              </div>
              <p className="text-xs truncate text-foreground/80 font-mono">{session.lastMsg}</p>
            </div>

            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="flex-1 h-8 text-xs font-mono border-red-500/20 text-red-400 hover:bg-red-500/10 hover:text-red-300">
                <StopCircle size={12} className="mr-2" />
                TERMINATE
              </Button>
              <Button size="sm" variant="outline" className="h-8 w-8 p-0 border-border/50">
                <RefreshCw size={12} />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
