import React from 'react';
import { Terminal, Shield, Activity, Users, Settings, LogOut } from 'lucide-react';
import { useLocation, Link } from 'wouter';

export function CyberLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const NavItem = ({ href, icon: Icon, label }: { href: string; icon: any; label: string }) => {
    const isActive = location === href;
    return (
      <Link href={href}>
        <div className={`
          flex items-center gap-3 px-4 py-3 cursor-pointer transition-all duration-300 border-l-2
          ${isActive 
            ? 'border-primary bg-primary/10 text-primary' 
            : 'border-transparent text-muted-foreground hover:text-foreground hover:bg-white/5'}
        `}>
          <Icon size={18} />
          <span className="font-mono text-sm tracking-wide">{label}</span>
        </div>
      </Link>
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative font-sans selection:bg-primary/30">
      <div className="scan-line" />
      
      <div className="flex h-screen overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 bg-card border-r border-border/50 hidden md:flex flex-col z-10">
          <div className="p-6 border-b border-border/50">
            <div className="flex items-center gap-2 text-primary animate-pulse">
              <Shield size={24} />
              <h1 className="font-mono font-bold text-lg tracking-wider">CYBER<span className="text-foreground">BOT</span></h1>
            </div>
            <div className="mt-2 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs text-muted-foreground font-mono">SYSTEM ONLINE</span>
            </div>
          </div>

          <nav className="flex-1 py-6 space-y-1">
            <NavItem href="/" icon={Activity} label="DASHBOARD" />
            <NavItem href="/sessions" icon={Users} label="ACTIVE SESSIONS" />
            <NavItem href="/logs" icon={Terminal} label="SYSTEM LOGS" />
            <NavItem href="/settings" icon={Settings} label="CONFIGURATION" />
          </nav>

          <div className="p-4 border-t border-border/50">
            <button className="flex items-center gap-2 text-xs font-mono text-red-400 hover:text-red-300 transition-colors w-full px-4 py-2 rounded border border-red-900/30 hover:bg-red-900/10 hover:border-red-900/50">
              <LogOut size={14} />
              DISCONNECT
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto relative z-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/5 via-background to-background pointer-events-none" />
          <div className="p-4 md:p-8 max-w-7xl mx-auto relative z-10">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
