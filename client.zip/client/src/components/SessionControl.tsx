import { Play, Square, Upload, Key, User, Clock, MessageSquare, AlertCircle } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

export function SessionControl() {
  const { toast } = useToast();
  const { register, handleSubmit, formState: { isSubmitting } } = useForm();

  const onSubmit = async (data: any) => {
    // Simulation of API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    toast({
      title: "SESSION INITIATED",
      description: `Target ${data.targetID} acquired. Attack sequence started.`,
      variant: "default",
      className: "bg-background border-primary text-primary font-mono"
    });
  };

  return (
    <div className="cyber-panel p-6 rounded-lg h-full">
      <div className="flex items-center gap-2 mb-6 border-b border-border/50 pb-4">
        <Play className="text-primary" size={20} />
        <h2 className="font-mono text-lg font-bold tracking-wider">NEW_SESSION_CONFIG</h2>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="font-mono text-xs text-muted-foreground uppercase">Target ID</Label>
            <div className="relative">
              <User className="absolute left-3 top-2.5 text-primary/50" size={16} />
              <Input 
                {...register('targetID')}
                placeholder="100084..." 
                className="pl-9 cyber-input"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="font-mono text-xs text-muted-foreground uppercase">Hater Name</Label>
            <div className="relative">
              <MessageSquare className="absolute left-3 top-2.5 text-primary/50" size={16} />
              <Input 
                {...register('hatersname')}
                placeholder="CyberGhost" 
                className="pl-9 cyber-input"
              />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label className="font-mono text-xs text-muted-foreground uppercase">App State (Cookies)</Label>
          <Textarea 
            {...register('cookies')}
            placeholder='[{"key":"c_user","value":"..."},{"key":"xs","value":"..."}]'
            className="cyber-input min-h-[100px] font-mono text-xs"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
           <div className="space-y-2">
            <Label className="font-mono text-xs text-muted-foreground uppercase">Messages File (.txt)</Label>
            <div className="relative border border-dashed border-border/50 rounded-md p-4 bg-black/20 hover:bg-primary/5 transition-colors cursor-pointer group text-center">
              <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" />
              <Upload className="mx-auto text-primary/50 group-hover:text-primary mb-2 transition-colors" size={20} />
              <span className="text-xs text-muted-foreground font-mono group-hover:text-primary/80">UPLOAD_PAYLOAD</span>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="font-mono text-xs text-muted-foreground uppercase">Timer (Seconds)</Label>
            <div className="relative">
              <Clock className="absolute left-3 top-2.5 text-primary/50" size={16} />
              <Input 
                type="number" 
                {...register('timer')}
                defaultValue={60}
                className="pl-9 cyber-input"
              />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label className="font-mono text-xs text-muted-foreground uppercase">Auth Key</Label>
          <div className="relative">
            <Key className="absolute left-3 top-2.5 text-primary/50" size={16} />
            <Input 
              type="password"
              {...register('password')}
              placeholder="••••••••••••"
              className="pl-9 cyber-input"
            />
          </div>
        </div>

        <Button 
          type="submit" 
          disabled={isSubmitting}
          className="w-full bg-primary text-background hover:bg-primary/90 font-mono font-bold tracking-wider mt-4"
        >
          {isSubmitting ? 'INITIALIZING...' : 'INITIATE_SEQUENCE'}
        </Button>
      </form>
    </div>
  );
}
