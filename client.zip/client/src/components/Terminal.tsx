import { Terminal } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

interface LogEntry {
  timestamp: string;
  type: 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS';
  message: string;
}

export function TerminalLog() {
  const [logs, setLogs] = useState<LogEntry[]>([
    { timestamp: new Date().toLocaleTimeString(), type: 'INFO', message: 'System initialized' },
    { timestamp: new Date().toLocaleTimeString(), type: 'INFO', message: 'Connecting to secure socket layer...' },
    { timestamp: new Date().toLocaleTimeString(), type: 'SUCCESS', message: 'Connection established' },
  ]);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  // Simulate incoming logs
  useEffect(() => {
    const interval = setInterval(() => {
      const types: ('INFO' | 'WARN' | 'SUCCESS')[] = ['INFO', 'INFO', 'SUCCESS', 'WARN'];
      const messages = [
        'Heartbeat signal received',
        'Validating session tokens...',
        'Packet size: 1024 bytes',
        'Encryption key rotated',
        'Garbage collection started',
        'Memory usage stable at 45%'
      ];
      
      const newLog: LogEntry = {
        timestamp: new Date().toLocaleTimeString(),
        type: types[Math.floor(Math.random() * types.length)],
        message: messages[Math.floor(Math.random() * messages.length)]
      };

      setLogs(prev => [...prev.slice(-50), newLog]);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="cyber-panel rounded-lg flex flex-col h-[400px]">
      <div className="px-4 py-2 border-b border-border/50 bg-black/20 flex items-center justify-between">
        <div className="flex items-center gap-2 text-primary/80">
          <Terminal size={14} />
          <span className="font-mono text-xs font-bold tracking-wider">LIVE_CONSOLE_OUTPUT</span>
        </div>
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500/20 border border-red-500/50" />
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/20 border border-yellow-500/50" />
          <div className="w-2.5 h-2.5 rounded-full bg-green-500/20 border border-green-500/50" />
        </div>
      </div>
      
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-1 bg-black/40">
        {logs.map((log, i) => (
          <div key={i} className="flex gap-3 hover:bg-white/5 p-0.5 rounded transition-colors">
            <span className="text-muted-foreground/50 shrink-0">[{log.timestamp}]</span>
            <span className={`shrink-0 font-bold w-16 ${
              log.type === 'ERROR' ? 'text-red-500' :
              log.type === 'SUCCESS' ? 'text-green-500' :
              log.type === 'WARN' ? 'text-yellow-500' :
              'text-blue-400'
            }`}>
              {log.type}
            </span>
            <span className="text-foreground/80">{log.message}</span>
          </div>
        ))}
        <div className="animate-pulse text-primary">_</div>
      </div>
    </div>
  );
}
